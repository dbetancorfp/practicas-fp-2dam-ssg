# Odoo 17 con Docker Compose

Este paquete levanta Odoo 17 y PostgreSQL 15. Los servicios guardan sus datos en volúmenes de Docker, no en directorios de datos enlazados desde el sistema de archivos del equipo.

## Preparación y credenciales

1. Extrae el ZIP en una carpeta de trabajo. En la carpeta extraída deben quedar `docker-compose.yml`, `.env.example`, `INSTRUCCIONES.md` y las carpetas `config/` y `addons/`.
2. Abre una terminal **en la raíz del paquete**, es decir, en la carpeta que contiene `docker-compose.yml`. Ejecuta allí los comandos Compose de esta guía; no los ejecutes desde dentro de `config/` ni desde otra carpeta.
3. Copia `.env.example` a `.env` en esa raíz.
4. Edita `.env` y sustituye los dos valores `CAMBIAR_POR_...` por contraseñas seguras. No compartas ni publiques `.env`.
5. `POSTGRES_DB` identifica la base técnica inicial de PostgreSQL (`postgres`); no es la base de práctica de Odoo. `POSTGRES_USER` / `POSTGRES_PASSWORD` son las credenciales que Odoo utiliza para conectarse al servicio Compose `db` (puerto `5432`). Dentro de la red de Compose, `db` es el nombre DNS del servicio PostgreSQL; no uses `localhost` como host desde Odoo.
6. `ODOO_MASTER_PASSWORD` es la contraseña maestra del administrador de bases de datos de Odoo. No es la contraseña de inicio de sesión de una cuenta de usuario de Odoo; al crear la base de datos también se establecerá la contraseña de la cuenta administradora de esa base.

## Inicio y creación de la base de datos

Inicia los servicios desde esta carpeta:

```sh
docker compose up -d
```

El comando se ejecuta en segundo plano. Comprueba el estado y los logs mientras termina el arranque:

```sh
docker compose ps
docker compose logs --tail=100 odoo
```

`docker compose ps` muestra si los contenedores están en ejecución; Odoo no tiene un healthcheck definido en este paquete, así que el estado `running` por sí solo no confirma que ya atienda peticiones HTTP. Espera a que sus logs indiquen que el servicio HTTP está iniciado (por ejemplo, `HTTP service (werkzeug) running on 0.0.0.0:8069`) y comprueba en un navegador <http://localhost:8069/web/login>. También puedes consultar el código HTTP con `curl -sS -o /dev/null -w 'HTTP %{http_code}\n' http://localhost:8069/web/login`: una respuesta HTTP (por ejemplo, `200` o una redirección `3xx`) confirma que el servidor está contestando.

Cuando aparezca la pantalla de creación de la base de datos, puedes usar cualquier nombre salvo `odoo` y `postgres`, que son las dos bases técnicas excluidas por el filtro. No se exige el prefijo `odoo_`. Introduce el valor de `ODOO_MASTER_PASSWORD` de tu `.env` como **contraseña maestra**. Esta contraseña no es la contraseña del usuario administrador de la base de datos; esa se elige por separado en el formulario.

El filtro configurado en `config/odoo.conf` (`^(?!postgres$)(?!odoo$).+$`) excluye únicamente los nombres exactos `odoo` y `postgres`; permite otros nombres, incluidos los de prácticas ya existentes (por ejemplo, `myDBTest`). Si tras crear una base vuelves a ver el formulario de creación, una causa posible es que el filtro efectivo de Odoo no esté mostrando esa base. Comprueba que su nombre no sea exactamente `odoo` o `postgres` y que esté aplicada esta configuración. Para aplicar la configuración actualizada, ejecuta desde la misma carpeta del paquete y con el mismo proyecto Compose:

```sh
docker compose up -d --no-deps --force-recreate odoo
```

Esto recrea solo el servicio `odoo`; no cambies el nombre del proyecto Compose ni los nombres de los volúmenes. No borres los volúmenes ni la base para resolver este síntoma.

Si Compose muestra un aviso de que hay un servicio huérfano llamado `web`, puede pertenecer a una configuración antigua del paquete. No ejecutes `docker compose down --remove-orphans` ni uses `--remove-orphans` a ciegas: primero averigua qué proyecto/servicio lo creó, porque esa opción elimina contenedores huérfanos.

## Acceso

- Interfaz de Odoo: <http://localhost:8069>
- Para entrar en una base ya existente, abre <http://localhost:8069/web/login>; si Odoo solicita elegir base, selecciona la existente (por ejemplo, `myDBTest`) y accede con las credenciales de una cuenta de usuario de esa base, no con la contraseña maestra. El filtro permite la base siempre que su nombre no sea exactamente `odoo` o `postgres`.
- Al crear una base, guarda el correo electrónico y la contraseña de administrador que introdujiste en el formulario. Para iniciar sesión, abre <http://localhost:8069/web/login>, selecciona esa base si se solicita y usa esas credenciales. La contraseña maestra solo se utiliza para operaciones de gestión de bases de datos.
- Para probar la tienda en esa base, abre **Aplicaciones**, busca **Website** y pulsa **Instalar**. Cuando termine, vuelve a **Aplicaciones**, busca **eCommerce** e instálalo si aún no está instalado. Después visita <http://localhost:8069/shop>. Si la página carga pero no muestra productos, crea o publica un producto de prueba desde la gestión de productos y vuelve a cargar `/shop`.

Al arrancar, el wrapper conserva la configuración base de `/etc/odoo/odoo.conf` y genera `/tmp/odoo.conf` con `admin_passwd`, `db_host = db`, `db_port = 5432`, `db_user` y `db_password`. Los valores de contraseña y usuario se obtienen de las variables de entorno del contenedor; el archivo temporal se crea con permisos restrictivos (`umask 077` y modo `600`). Las credenciales no se pasan como argumentos de Odoo ni se incluyen en el ZIP.

## Diagnóstico

Si Odoo no conecta con PostgreSQL, confirma que la configuración apunta al servicio `db`, que este aparece como `healthy` y que `.env` contiene las credenciales correspondientes. Consulta los logs de ambos servicios:

```sh
docker compose ps
docker compose logs --tail=200 odoo db
```

Ante un error HTTP 500, revisa especialmente el traceback de Odoo en esos logs. Para pedir ayuda, comparte el traceback y el mensaje de error, pero elimina antes contraseñas, valores de `.env`, tokens, datos personales y cualquier otro secreto. No compartas `.env` ni el contenido de los volúmenes, y no borres volúmenes para intentar corregir el error: podrías perder la base de datos o el filestore.

Para seguir los logs en tiempo real:

```sh
docker compose logs -f db odoo
```

## Persistencia y parada

`db-data` conserva los datos de PostgreSQL y `odoo-data` conserva los datos de Odoo, incluido el filestore. Son volúmenes gestionados por Docker (Docker puede anteponerles el nombre del proyecto Compose); no son carpetas del equipo. Así se evita depender de permisos de escritura en un bind mount, por ejemplo sobre `fuseblk`. La configuración y los addons se montan desde `config/` y `addons/` en modo solo lectura.

- Para reanudar contenedores existentes que se habían detenido con `docker compose stop`, ejecuta `docker compose start`. También puedes usar `docker compose up -d` desde la raíz del paquete; crea los contenedores que falten y arranca los servicios.
- Para detener los servicios sin borrar contenedores ni datos, ejecuta `docker compose stop`.
- `docker compose down` detiene y elimina los contenedores y la red del proyecto, pero **conserva** ambos volúmenes.
- **No ejecutes `docker compose down -v`** si quieres conservar la instalación: elimina también los volúmenes del proyecto y, con ellos, la base de datos y el filestore. No es un paso de diagnóstico ni de parada normal.

## Copia de seguridad

Haz copias mientras los servicios estén disponibles y guarda los archivos fuera de los volúmenes y del paquete. Para exportar la base de práctica (sustituye `odoo_practicas` por el nombre que creaste si es distinto):

```sh
docker compose exec -T db pg_dump -U odoo -d odoo_practicas > odoo-db.sql
```

La base de datos no incluye el filestore. Para respaldarlo, identifica el volumen real de Odoo con `docker volume ls` (Compose suele añadir el nombre del proyecto y el sufijo `odoo-data`) y archívalo, por ejemplo:

```sh
docker run --rm -v NOMBRE_REAL_DEL_VOLUMEN_ODOO:/data:ro -v "$PWD:/backup" alpine \
  tar -czf /backup/odoo-filestore.tar.gz -C /data .
```

Conserva juntos el volcado SQL y el archivo del filestore, y comprueba periódicamente que pueden leerse y restaurarse. No borres los volúmenes antes de verificar una copia recuperable.
